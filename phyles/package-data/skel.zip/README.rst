%(package-header)s

Introduction
------------

A few words to introduce package.


Home Page & Repository
----------------------

Location of home page and code repository.


Example
-------

Example of how to use it and what it can do.
